// 비디오
let video;

// posenet
let poseNet;
let pose, skeleton;

// 얼굴
let nose, leftEye, rightEye;

function setup() {
  createCanvas(640, 480);
  
  // 비디오
  video = createCapture(VIDEO);
  video.size(width, height);
  video.hide();
  
  poseNet = ml5.poseNet(video, modelLoaded);
  
  poseNet.on('pose', gotResults);
}

function modelLoaded() {
  console.log('modelLoaded!')
}

function gotResults(p) {
  pose = p[0]?.pose;
  skeleton = p[0]?.skeleton;
  
  if (pose) {
    nose = pose.nose;
    leftEye = pose.leftEye;
    rightEye = pose.rightEye;
    drawFace();
  }
  
  if (pose) console.log("pose", pose);
  if (skeleton) console.log("skeleton", skeleton);
}

function drawFace() {
  fill(255);
  ellipse(leftEye.x, leftEye.y, 20, 30);
  ellipse(rightEye.x, rightEye.y, 20, 30);
  circle(nose.x, nose.y, 10);
  
  fill(0);
  circle(leftEye.x, leftEye.y, 10);
  circle(rightEye.x, rightEye.y, 10);
}

function drawSkeleton() {
  if (skeleton) {
    for(let item of skeleton) {
      let a = item[0];
      let b = item[1];
      
      stroke(255);
      line(a.position.x, a.position.y, b.position.x, b.position.y);
    }
  }
}

function draw() {
  background(0);
  
  //image(video, 0, 0, width, height);
  if (pose) {
    drawFace();
    drawSkeleton();
  }
}